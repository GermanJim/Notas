package com.example.notes.utils

import androidx.compose.ui.unit.dp

val APP_BAR_HEIGHT = 56.dp
val SEARCH_TEXT_FIELD_HEIGHT = 50.dp