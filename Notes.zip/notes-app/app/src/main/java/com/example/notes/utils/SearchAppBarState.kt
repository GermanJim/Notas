package com.example.notes.utils

enum class SearchAppBarState {
    OPENED,
    CLOSED,
    TRIGGERED
}