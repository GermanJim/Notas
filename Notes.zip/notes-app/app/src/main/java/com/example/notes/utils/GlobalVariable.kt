package com.example.notes.utils

object GlobalVariable {

    var hasNotificationPermission: Boolean = false
}