package com.example.notes.ui.theme

import androidx.compose.material.Typography

// Set of Material typography styles to start with
val Typography = Typography()